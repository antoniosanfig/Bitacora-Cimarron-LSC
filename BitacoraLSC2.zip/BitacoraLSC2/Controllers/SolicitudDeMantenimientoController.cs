﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BitacoraLSC2.Models;

namespace BitacoraLSC2.Controllers
{
    public class SolicitudDeMantenimientoController : Controller
    {
        private BitacoraLSCEntities3 db = new BitacoraLSCEntities3();
        private BitacoraLSCEntities1 db2 = new BitacoraLSCEntities1();
        // GET: SolicitudDeMantenimiento
        public ActionResult Index()
        {
            return View(db.SolicitudDeMantenimiento.ToList());
        }

        // GET: SolicitudDeMantenimiento/Details/5
        public ActionResult Details(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SolicitudDeMantenimiento solicitudDeMantenimiento = db.SolicitudDeMantenimiento.Find(id);
            if (solicitudDeMantenimiento == null)
            {
                return HttpNotFound();
            }
            return View(solicitudDeMantenimiento);
        }

        // GET: SolicitudDeMantenimiento/Create
        public ActionResult Create()
        {
              List<Models.ViewModel.EquipoViewModel> lista = (
                   from d in db2.Equipo
                   select new Models.ViewModel.EquipoViewModel
                   {
                       ID = d.ID,
                       nombre = d.nombre
                   }).ToList();

       List<SelectListItem> items = lista.ConvertAll(d =>
       {
           return new SelectListItem()
           {
               Text = d.ID.ToString(),
               Value = d.ID.ToString(),
               Selected = false
           };
       });

       ViewBag.items = items;
            return View();
        }

        // POST: SolicitudDeMantenimiento/Create
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "IDSolicitud,equipo,tipoDeMantenimiento,descripcion,estado,fechaRegistrada,fechaDeMantenimiento")] SolicitudDeMantenimiento solicitudDeMantenimiento)
        {
            List<Models.ViewModel.EquipoViewModel> lista = (
                   from d in db2.Equipo
                   select new Models.ViewModel.EquipoViewModel
                   {
                       ID = d.ID,
                       nombre = d.nombre
                   }).ToList();

            List<SelectListItem> items = lista.ConvertAll(d =>
            {
                return new SelectListItem()
                {
                    Text = d.nombre.ToString(),
                    Value = d.ID.ToString(),
                    Selected = false
                };
            });
            int ID=1;
            string n="";
            n = ID + "";
            SolicitudDeMantenimiento sd = db.SolicitudDeMantenimiento.Find(n);
            do
            {
                ID++;
                n = ID + "";
                sd = db.SolicitudDeMantenimiento.Find(n);
            } while (sd != null);
            
            solicitudDeMantenimiento.IDSolicitud = n;
            solicitudDeMantenimiento.estado = "Pendiente";
            solicitudDeMantenimiento.fechaRegistrada = System.DateTime.Now;


            if (ModelState.IsValid)
            {
                db.SolicitudDeMantenimiento.Add(solicitudDeMantenimiento);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(solicitudDeMantenimiento);
        }

        // GET: SolicitudDeMantenimiento/Edit/5
        public ActionResult Edit(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SolicitudDeMantenimiento solicitudDeMantenimiento = db.SolicitudDeMantenimiento.Find(id);
            if (solicitudDeMantenimiento == null)
            {
                return HttpNotFound();
            }
            return View(solicitudDeMantenimiento);
        }

        // POST: SolicitudDeMantenimiento/Edit/5
        // Para protegerse de ataques de publicación excesiva, habilite las propiedades específicas a las que quiere enlazarse. Para obtener 
        // más detalles, vea https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "IDSolicitud,equipo,tipoDeMantenimiento,descripcion,estado,fechaRegistrada,fechaDeMantenimiento")] SolicitudDeMantenimiento solicitudDeMantenimiento)
        {
            if (solicitudDeMantenimiento.estado == "EnProceso")
            {
                Equipo equipo = db2.Equipo.Find(solicitudDeMantenimiento.equipo);
                equipo.estado = "En Mantenimiento";
                db2.Entry(equipo).State = EntityState.Modified;
                db2.SaveChanges();
            }
            else if (solicitudDeMantenimiento.estado == "Realizada")
            {
                Equipo equipo = db2.Equipo.Find(solicitudDeMantenimiento.equipo);
                equipo.estado = "Disponible";
                db2.Entry(equipo).State = EntityState.Modified;
                db2.SaveChanges();
            }

            if (ModelState.IsValid)
            {
                db.Entry(solicitudDeMantenimiento).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(solicitudDeMantenimiento);
        }

        // GET: SolicitudDeMantenimiento/Delete/5
        public ActionResult Delete(string id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SolicitudDeMantenimiento solicitudDeMantenimiento = db.SolicitudDeMantenimiento.Find(id);
            if (solicitudDeMantenimiento == null)
            {
                return HttpNotFound();
            }
            return View(solicitudDeMantenimiento);
        }

        // POST: SolicitudDeMantenimiento/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(string id)
        {
            SolicitudDeMantenimiento solicitudDeMantenimiento = db.SolicitudDeMantenimiento.Find(id);
            db.SolicitudDeMantenimiento.Remove(solicitudDeMantenimiento);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        public ActionResult ActualizarSolicitud([Bind(Include = "IDSolicitud,equipo,tipoDeMantenimiento,descripcion,estado,fechaRegistrada,fechaDeMantenimiento")] SolicitudDeMantenimiento solicitudDeMantenimiento)
        {
            if (ModelState.IsValid)
            {
                if (solicitudDeMantenimiento.estado == "EnProceso")
                {
                    Equipo equipo = db2.Equipo.Find(solicitudDeMantenimiento.equipo);
                    equipo.estado = "En Mantenimiento";
                    db2.Entry(equipo).State = EntityState.Modified;
                    db2.SaveChanges();
                }
                else if(solicitudDeMantenimiento.estado == "Realizada")
                {
                    Equipo equipo = db2.Equipo.Find(solicitudDeMantenimiento.equipo);
                    equipo.estado = "Disponible";
                    db2.Entry(equipo).State = EntityState.Modified;
                    db2.SaveChanges();
                }
                
                db.Entry(solicitudDeMantenimiento).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(solicitudDeMantenimiento);
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
                db2.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
